/*
  Warnings:

  - You are about to drop the column `subtotal` on the `receipts` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "public"."receipts" DROP COLUMN "subtotal";
