-- AlterTable
ALTER TABLE "public"."receipts" ADD COLUMN     "imageData" TEXT;
